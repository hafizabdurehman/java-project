package drone;

import java.io.IOException;

public interface Camera 
{
	public void startCamera(int time) throws IOException;
}
