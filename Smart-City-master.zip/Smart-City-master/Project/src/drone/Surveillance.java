package drone;

import java.io.IOException;

public interface Surveillance
{
	public void informPolice(Object a);
	public void showImage(String a) throws IOException;
}
